# Maya AI Assistant — প্রাথমিক Android প্রজেক্ট

এই প্রজেক্টটি একটি বিনামূল্যের starter build। এতে:
- Android SpeechRecognizer দিয়ে কথা থেকে লেখা
- Android TextToSpeech দিয়ে কণ্ঠে উত্তর
- “Hey Maya” শনাক্ত করার প্রাথমিক ব্যবস্থা
- গাঢ় বেগুনি সাধারণ UI

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি এখনো ChatGPT বা অন্য AI API-র সঙ্গে যুক্ত নয়; তাই বুদ্ধিমান AI উত্তর দেয় না।
- “Hey Maya” সবসময় শোনার নিশ্চয়তা নেই। অ্যাপ খোলা ও চালু থাকতে হবে; Android-এর speech recognition পরিষেবা ফোন/ইন্টারনেট অনুযায়ী কাজ করতে পারে।
- বাংলা voice আপনার ফোনে ইনস্টল করা TTS voice-এর ওপর নির্ভর করে।
- এটি একটি starter source project, তৈরি APK নয়।

## APK বিনামূল্যে তৈরি করার উপায় (কম্পিউটার ছাড়াই সম্ভব, তবে GitHub অ্যাকাউন্ট লাগবে)
1. GitHub-এ একটি নতুন repository তৈরি করুন।
2. এই ZIP-এর ফাইলগুলো repository-তে আপলোড করুন; `.github/workflows/build-apk.yml`-সহ সব ফাইল রাখতে হবে।
3. repository-র **Actions** ট্যাবে যান।
4. **Build Maya APK** workflow বেছে **Run workflow** চাপুন।
5. workflow সফল হলে run খুলে **Artifacts** থেকে `Maya-debug-apk` ডাউনলোড করুন।
6. ZIP খুলে `app-debug.apk` ফোনে ট্যাপ করে ইনস্টল করুন। Android যদি অনুমতি চায়, শুধু আপনার বিশ্বাসযোগ্য নিজের তৈরি APK ইনস্টল করার অনুমতি দিন।

## বিল্ডের বিকল্প
আপনি আগের MIT App Inventor “Maya” প্রজেক্টেই কাজ চালিয়ে যেতে পারেন। সেখানে Build → Android App (.apk) নির্বাচন করে APK বানানো যায়।
