package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.util.TypedValue
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var startButton: Button
    private var ttsReady = false
    private var waitingForCommand = false
    private var listeningEnabled = false
    private var listeningNow = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        } else {
            prepareRecognizer()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(32), dp(24), dp(32))
            setBackgroundColor(Color.rgb(18, 16, 42))
        }
        val title = TextView(this).apply {
            text = "MAYA"
            setTextColor(Color.rgb(210, 197, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 36f)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "AI Voice Assistant"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "শুরু করার জন্য নিচের বোতাম চাপো"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(12))
        }
        heardText = TextView(this).apply {
            text = "কথা এখানে দেখা যাবে"
            setTextColor(Color.rgb(200, 200, 220))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(24))
        }
        startButton = Button(this).apply {
            text = "Maya চালু করো"
            setOnClickListener { startListening() }
        }
        val stopButton = Button(this).apply {
            text = "শোনা বন্ধ করো"
            setOnClickListener {
                listeningEnabled = false
                listeningNow = false
                try { recognizer?.cancel() } catch (_: Exception) {}
                statusText.text = "শোনা বন্ধ আছে"
                startButton.visibility = View.VISIBLE
            }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(statusText)
        root.addView(heardText)
        root.addView(startButton)
        root.addView(stopButton)
        setContentView(root)
    }

    private fun prepareRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "এই ফোনে speech recognition পাওয়া যায়নি।"
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    listeningNow = true
                    statusText.text = "শুনছি… বলো “Hey Maya”"
                }
                override fun onBeginningOfSpeech() { statusText.text = "তোমার কথা শুনছি…" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listeningNow = false }
                override fun onError(error: Int) {
                    listeningNow = false
                    if (listeningEnabled) {
                        statusText.text = "আবার শুনতে প্রস্তুত হচ্ছি…"
                        statusText.postDelayed({ if (listeningEnabled) listenOnce() }, 900)
                    }
                }
                override fun onResults(results: Bundle?) {
                    listeningNow = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull().orEmpty()
                    heardText.text = "তুমি বলেছ: $spoken"
                    handleSpeech(spoken)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (recognizer == null) prepareRecognizer()
        listeningEnabled = true
        waitingForCommand = false
        startButton.visibility = View.GONE
        listenOnce()
    }

    private fun listenOnce() {
        if (!listeningEnabled || isFinishing || listeningNow) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listeningNow = false
            statusText.text = "মাইক্রোফোন চালু করা যায়নি। আবার চেষ্টা করো।"
        }
    }

    private fun handleSpeech(raw: String) {
        val spoken = raw.lowercase(Locale.ROOT)
        if (spoken.contains("hey maya") || spoken.contains("হে মায়া") ||
            spoken.contains("হেই মায়া") || spoken.contains("হে মায়া") ||
            spoken.contains("হেই মায়া")) {
            waitingForCommand = true
            speak("হ্যাঁ, বলো! আমি শুনছি।") {
                if (listeningEnabled) listenOnce()
            }
            return
        }
        if (waitingForCommand) {
            waitingForCommand = false
            // This starter build only demonstrates speech input/output.
            // Connect an AI API to generate intelligent answers in a later version.
            speak("তুমি বলেছ: $raw। এখনো আমার AI উত্তর ব্যবস্থা যুক্ত করা হয়নি।") {
                if (listeningEnabled) listenOnce()
            }
            return
        }
        statusText.text = "আমাকে ডাকতে বলো: Hey Maya"
        if (listeningEnabled) statusText.postDelayed({ listenOnce() }, 700)
    }

    private fun speak(text: String, after: (() -> Unit)? = null) {
        statusText.text = text
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_speech")
            if (after != null) {
                statusText.postDelayed(after, 1800)
            }
        } else if (after != null) {
            statusText.postDelayed(after, 1000)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "IN"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prepareRecognizer()
            statusText.text = "প্রস্তুত। Maya চালু করো চাপো।"
        } else if (requestCode == 100) {
            statusText.text = "Maya চালাতে মাইক্রোফোন অনুমতি দরকার।"
        }
    }

    override fun onDestroy() {
        listeningEnabled = false
        try { recognizer?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
